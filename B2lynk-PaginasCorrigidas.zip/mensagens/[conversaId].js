export default function Conversa() {
  return <div>Conversa Individual</div>;
}