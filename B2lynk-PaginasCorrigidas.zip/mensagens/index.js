export default function Mensagens() {
  return <div>Página de Mensagens</div>;
}