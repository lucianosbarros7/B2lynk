export default function MensagensIndex() {
  return <div>Página de listagem de mensagens</div>;
}
