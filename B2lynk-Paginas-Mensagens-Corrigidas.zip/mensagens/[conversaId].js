export default function MensagemDetalhe() {
  return <div>Visualizando conversa específica</div>;
}
