export default function MeusFavoritos() {
  return <div>Página: MeusFavoritos</div>;
}