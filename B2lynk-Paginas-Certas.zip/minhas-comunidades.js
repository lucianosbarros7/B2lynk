export default function MinhasComunidades() {
  return <div>Página: MinhasComunidades</div>;
}