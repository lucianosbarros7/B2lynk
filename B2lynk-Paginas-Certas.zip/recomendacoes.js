export default function Recomendacoes() {
  return <div>Página: Recomendacoes</div>;
}