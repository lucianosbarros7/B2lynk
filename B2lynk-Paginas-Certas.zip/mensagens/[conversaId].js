export default function Conversa() {
  return <div>Página: Conversa</div>;
}