export default function Mensagens() {
  return <div>Página: Mensagens</div>;
}