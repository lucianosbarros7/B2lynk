export default function Dashboard() {
  return <div>Página: Dashboard</div>;
}