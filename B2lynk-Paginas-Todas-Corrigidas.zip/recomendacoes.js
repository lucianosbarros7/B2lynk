export default function Recomendacoes() {
  return <div>Página de Recomendações</div>;
}