// Página inicial
export default function Home() { return <h1>Bem-vindo ao B2lynk</h1> }