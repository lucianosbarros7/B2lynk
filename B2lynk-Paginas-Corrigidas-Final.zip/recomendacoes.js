export default function Recomendacoes() {
  return <div>Página Recomendações</div>;
}