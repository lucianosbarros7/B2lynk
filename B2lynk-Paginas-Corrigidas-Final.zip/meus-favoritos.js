export default function MeusFavoritos() {
  return <div>Página Meus Favoritos</div>;
}