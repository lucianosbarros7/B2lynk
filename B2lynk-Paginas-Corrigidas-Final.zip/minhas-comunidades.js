export default function MinhasComunidades() {
  return <div>Página Minhas Comunidades</div>;
}