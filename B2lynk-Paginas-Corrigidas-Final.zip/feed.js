export default function Feed() {
  return <div>Página Feed</div>;
}