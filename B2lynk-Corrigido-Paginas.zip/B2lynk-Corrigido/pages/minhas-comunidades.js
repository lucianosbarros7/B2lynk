export default function MinhasComunidades() {
  return (
    <div>
      <h1>MinhasComunidades</h1>
    </div>
  );
}