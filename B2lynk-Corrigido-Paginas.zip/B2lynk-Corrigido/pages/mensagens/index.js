export default function MensagensIndex() {
  return (
    <div>
      <h1>MensagensIndex</h1>
    </div>
  );
}