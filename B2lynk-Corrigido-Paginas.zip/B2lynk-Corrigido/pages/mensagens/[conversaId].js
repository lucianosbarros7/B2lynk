export default function Conversa() {
  return (
    <div>
      <h1>Conversa</h1>
    </div>
  );
}