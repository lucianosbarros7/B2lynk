export default function Recomendacoes() {
  return (
    <div>
      <h1>Recomendacoes</h1>
    </div>
  );
}