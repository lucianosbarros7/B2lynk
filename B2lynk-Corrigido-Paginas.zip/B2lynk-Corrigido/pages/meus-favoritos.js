export default function MeusFavoritos() {
  return (
    <div>
      <h1>MeusFavoritos</h1>
    </div>
  );
}