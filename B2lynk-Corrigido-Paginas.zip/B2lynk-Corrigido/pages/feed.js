export default function Feed() {
  return (
    <div>
      <h1>Feed</h1>
    </div>
  );
}